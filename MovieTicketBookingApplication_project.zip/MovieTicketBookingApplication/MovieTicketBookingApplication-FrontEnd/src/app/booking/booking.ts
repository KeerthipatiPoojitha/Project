export class Booking {
  public transactionId: number;
  public transactionMode: string;
  public transactionStatus: string;
  public totalCost: number;
  public bookingDate: Date;
  show: any;
}
